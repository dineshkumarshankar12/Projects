from django.utils import timezone
from django.db import models
from datetime import timedelta

class Habit(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)
    reminder_time = models.TimeField(blank=True, null=True)

    def get_streak(self):
        """Calculate the current streak of consecutive days the habit was completed."""
        today = timezone.now().date()
        streak = 0

        # Iterate backward from today and check for consecutive completions
        for i in range(0, 7):  # Check up to 7 days
            date = today - timedelta(days=i)
            log = self.habitlog_set.filter(date=date, completed=True).first()
            if log:
                streak += 1
            else:
                break  # Streak is broken

        return streak

class HabitLog(models.Model):
    habit = models.ForeignKey(Habit, on_delete=models.CASCADE)
    date = models.DateField()
    completed = models.BooleanField(default=False)

    def _str_(self):
        return f"{self.habit.name} - {self.date} - {'Completed' if self.completed else 'Not Completed'}"