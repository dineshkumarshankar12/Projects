document.addEventListener('DOMContentLoaded', () => {
    const storedPolls = JSON.parse(localStorage.getItem('polls')) || [];
    const pollsList = document.getElementById('polls');
    const resultList = document.getElementById('result-list');
    const pollContainer = document.getElementById('poll-container');
    const pollResultContainer = document.getElementById('poll-result');
    const backToPollsButton = document.getElementById('back-to-polls');
    const createPollButton = document.getElementById('create-poll');

    const pollQuestionInput = document.getElementById('poll-question');
    const pollOption1Input = document.getElementById('poll-option1');
    const pollOption2Input = document.getElementById('poll-option2');
    function renderPolls() {
        pollsList.innerHTML = '';
        storedPolls.forEach((poll, index) => {
            const pollItem = document.createElement('li');
            pollItem.classList.add('poll-item');
            pollItem.innerHTML = `
                <strong>${poll.question}</strong><br>
                <button onclick="viewResults(${index})">Vote</button>
            `;
            pollsList.appendChild(pollItem);
        });
    }
    createPollButton.addEventListener('click', () => {
        const question = pollQuestionInput.value;
        const option1 = pollOption1Input.value;
        const option2 = pollOption2Input.value;

        if (question && option1 && option2) {
            const newPoll = {
                question: question,
                options: [
                    { text: option1, votes: 0 },
                    { text: option2, votes: 0 }
                ]
            };
            storedPolls.push(newPoll);
            localStorage.setItem('polls', JSON.stringify(storedPolls));
            pollQuestionInput.value = '';
            pollOption1Input.value = '';
            pollOption2Input.value = '';
            renderPolls();
        } else {
            alert("Please fill in all fields to create a poll.");
        }
    });
    window.viewResults = function(index) {
        const poll = storedPolls[index];
        pollContainer.style.display = 'none';
        pollResultContainer.style.display = 'block';
        resultList.innerHTML = '';
        poll.options.forEach((option, optionIndex) => {
            const resultItem = document.createElement('li');
            resultItem.innerHTML = `
                <strong>${option.text}</strong>: ${option.votes} votes
                <button onclick="vote(${index}, ${optionIndex})">Vote</button>
            `;
            resultList.appendChild(resultItem);
        });
    };
    window.vote = function(pollIndex, optionIndex) {
        storedPolls[pollIndex].options[optionIndex].votes += 1;
        localStorage.setItem('polls', JSON.stringify(storedPolls));
        viewResults(pollIndex); // Re-render the results after voting
    };
     backToPollsButton.addEventListener('click', ()=>{
       pollContainer.style.display = 'block';
       pollResultContainer.style.display = 'none';
     });
     renderPolls();
   });
