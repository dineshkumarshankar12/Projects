from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from django.contrib import messages
from django.views.decorators.http import require_POST
from .models import Habit, HabitLog
from .forms import HabitForm
import datetime

# View to display all habits with streak and progress
def habit_dashboard(request):
    today = datetime.date.today()
    habits = Habit.objects.all()

    habit_data = []
    for habit in habits:
        # Calculate streak
        streak = HabitLog.objects.filter(habit=habit, completed=True, date__lte=today).count()
        # Get weekly logs
        weekly_logs = HabitLog.objects.filter(habit=habit, date__gte=today - datetime.timedelta(days=7))
        habit_data.append({
            'habit': habit,
            'streak': streak,
            'weekly_logs': weekly_logs
        })
    
    # Data for the charts
    days_of_week = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    weekly_totals = [HabitLog.objects.filter(habit=habit, date__week=today.isocalendar().week).filter(completed=True).count() for habit in habits]


    return render(request, 'habit_dashboard.html', {
        'habit_data': habit_data,
        'today': today,
        'days_of_week': days_of_week,
        'weekly_totals': weekly_totals
    })

# View to add a new habit
def add_habit(request):
    if request.method == 'POST':
        form = HabitForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Habit added successfully!')
            return redirect('watch:habit_dashboard')
    else:
        form = HabitForm()
    return render(request, 'habit_form.html', {'form': form})

# View to edit a habit
def edit_habit(request, habit_id):
    habit = get_object_or_404(Habit, id=habit_id)
    if request.method == 'POST':
        form = HabitForm(request.POST, instance=habit)
        if form.is_valid():
            form.save()
            messages.success(request, 'Habit updated successfully!')
            return redirect('watch:habit_dashboard')
    else:
        form = HabitForm(instance=habit)
    return render(request, 'habit_form.html', {'form': form})

# View to delete a habit
@require_POST
def delete_habit(request, habit_id):
    habit = get_object_or_404(Habit, id=habit_id)
    habit.delete()
    messages.success(request, 'Habit deleted successfully!')
    return redirect('watch:habit_dashboard')

# View to toggle habit completion for a specific day
@require_POST
def toggle_habit(request, habit_id):
    habit = get_object_or_404(Habit, id=habit_id)
    today = datetime.date.today()

    # Check if the habit is already logged for today
    log, created = HabitLog.objects.get_or_create(habit=habit, date=today)

    # Toggle the completion state
    log.completed = not log.completed
    log.save()

    # Redirect back to the habit dashboard
    return redirect('watch:habit_dashboard')
