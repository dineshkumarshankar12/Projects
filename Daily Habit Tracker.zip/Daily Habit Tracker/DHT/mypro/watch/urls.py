from django.urls import path
from . import views

app_name = 'watch'

urlpatterns = [
    path('', views.habit_dashboard, name='habit_dashboard'),
    path('toggle/<int:habit_id>/', views.toggle_habit, name='toggle_habit'),
    path('add/', views.add_habit, name='add_habit'),
    path('edit/<int:habit_id>/', views.edit_habit, name='edit_habit'),  # Edit Habit URL
    path('delete/<int:habit_id>/', views.delete_habit, name='delete_habit'),  # Delete Habit URL
]
