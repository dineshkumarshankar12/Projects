# Version: 2.0.2

* [#46](https://github.com/saadmk11/banking-system/pull/46): Bump django from 3.1.8 to 3.1.9
* [#22](https://github.com/saadmk11/banking-system/pull/22): Bump django from 3.1.1 to 3.1.2
* [#26](https://github.com/saadmk11/banking-system/pull/26): Bump django from 3.1.2 to 3.1.3
* [#28](https://github.com/saadmk11/banking-system/pull/28): Bump django from 3.1.3 to 3.1.4
* [#24](https://github.com/saadmk11/banking-system/pull/24): Bump django-celery-beat from 2.0.0 to 2.1.0
* [#31](https://github.com/saadmk11/banking-system/pull/31): Bump django from 3.1.4 to 3.1.5
* [#34](https://github.com/saadmk11/banking-system/pull/34): Bump django from 3.1.5 to 3.1.7
* [#37](https://github.com/saadmk11/banking-system/pull/37): Bump django from 3.1.7 to 3.1.8
* [#40](https://github.com/saadmk11/banking-system/pull/40): Update GitHub Action Versions
* [#38](https://github.com/saadmk11/banking-system/pull/38): Add GitHub Actions Version Updater
* [#42](https://github.com/saadmk11/banking-system/pull/42): Update GitHub Action Versions
* [#39](https://github.com/saadmk11/banking-system/pull/39): Update GitHub Action Versions
* [#55](https://github.com/saadmk11/banking-system/pull/55): fixed page not found after login by registered user
* [#54](https://github.com/saadmk11/banking-system/pull/54): Bump django from 3.1.9 to 3.2.7
* [#52](https://github.com/saadmk11/banking-system/pull/52): Bump python-dateutil from 2.8.1 to 2.8.2


Version: 2.0.1
==============

* [#17](https://github.com/saadmk11/banking-system/pull/17): Create LICENSE
* [#16](https://github.com/saadmk11/banking-system/pull/16): Bump django from 3.1 to 3.1.1
* [#18](https://github.com/saadmk11/banking-system/pull/18): Add Changelog-ci
